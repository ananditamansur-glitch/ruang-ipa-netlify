import crypto from 'node:crypto';

const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const TOKEN_SECRET = process.env.TOKEN_SECRET || '';
const BUCKET = process.env.SUPABASE_STORAGE_BUCKET || 'ruang-ipa';

const headers = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const reply = (statusCode, body) => ({ statusCode, headers, body: JSON.stringify(body) });
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const b64url = (s) => Buffer.from(s).toString('base64url');
function makeToken(user) {
  const payload = b64url(JSON.stringify({ username: user.username, role: user.role, name: user.name, exp: Date.now() + 6 * 60 * 60 * 1000 }));
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}
function readToken(token) {
  if (!token || !TOKEN_SECRET) throw new Error('Sesi admin tidak tersedia. Periksa konfigurasi server.');
  const [payload, signature] = String(token).split('.');
  if (!payload || !signature) throw new Error('Sesi admin tidak valid. Silakan login kembali.');
  const expected = crypto.createHmac('sha256', TOKEN_SECRET).update(payload).digest();
  let got; try { got = Buffer.from(signature, 'base64url'); } catch { throw new Error('Sesi admin tidak valid.'); }
  if (got.length !== expected.length || !crypto.timingSafeEqual(got, expected)) throw new Error('Sesi admin tidak valid.');
  const user = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  if (!user.exp || user.exp < Date.now()) throw new Error('Sesi admin berakhir. Silakan login kembali.');
  return user;
}
async function sb(path, options = {}) {
  if (!SUPABASE_URL || !SERVICE_KEY) throw new Error('Konfigurasi Supabase belum lengkap. Atur SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY pada Environment variables Netlify.');
  const response = await fetch(`${SUPABASE_URL}${path}`, {
    ...options,
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
      ...(options.body && !(options.body instanceof Uint8Array) ? { 'content-type': 'application/json' } : {}),
      ...(options.headers || {})
    }
  });
  const raw = await response.text();
  let data = null; try { data = raw ? JSON.parse(raw) : null; } catch { data = raw; }
  if (!response.ok) throw new Error(data?.message || data?.hint || data?.error || `Supabase error ${response.status}: ${raw.slice(0, 300)}`);
  return data;
}
const enc = (s) => encodeURIComponent(String(s));
async function getRows(table, query = 'select=*') { return sb(`/rest/v1/${table}?${query}`); }
async function getSettings() {
  const rows = await getRows('settings', 'select=key,value');
  return Object.fromEntries((rows || []).map(r => [r.key, r.value]));
}
function toMaterial(r) {
  return { id: String(r.id || ''), title: String(r.title || ''), grade: Number(r.grade) || 7, type: String(r.type || 'URL'), description: String(r.description || ''), url: String(r.url || ''), driveId: String(r.drive_id || ''), fileName: String(r.file_name || ''), createdAt: r.created_at ? String(r.created_at) : '' };
}
async function initialData() {
  const [settings, materials, codes] = await Promise.all([
    getSettings(), getRows('materials', 'select=*&order=created_at.desc'), getRows('grade_codes', 'select=*&order=grade.asc')
  ]);
  return {
    title: String(settings.siteTitle || 'Ruang IPA'),
    runningText: String(settings.runningText || 'Selamat datang di Ruang IPA • Jelajahi dunia sains • Belajar IPA menjadi menyenangkan •'),
    welcomeText: String(settings.welcomeText || 'Perpustakaan Digital Belajar IPA untuk Kelas 7, 8, dan 9'),
    materials: (materials || []).map(toMaterial),
    gradeCodes: (codes || []).map(c => ({ grade: Number(c.grade), enabled: c.enabled === true, code: String(c.code || '') })),
    version: 'Netlify Edition V15.1.2'
  };
}
function requireAdmin(token) { const user = readToken(token); if (user.role !== 'admin') throw new Error('Akses hanya untuk admin.'); return user; }
async function handle(action, args) {
  switch (action) {
    case 'getInitialData': return await initialData();
    case 'login': {
      const [username, password] = args;
      const rows = await getRows('users', `select=username,password_hash,role,name&username=eq.${enc(username)}&limit=1`);
      const user = rows?.[0];
      if (!user || user.password_hash !== sha256(password)) return { ok: false, message: 'Username atau password salah.' };
      return { ok: true, token: makeToken({ username: user.username, role: user.role, name: user.name }), role: user.role, name: user.name };
    }
    case 'saveMaterial': {
      requireAdmin(args[0]); const item = args[1] || {};
      if (!String(item.title || '').trim() || !item.grade || !item.type) throw new Error('Judul, kelas, dan tipe materi wajib diisi.');
      if (![7, 8, 9].includes(Number(item.grade))) throw new Error('Kelas harus 7, 8, atau 9.');
      const row = { id: String(item.id || crypto.randomUUID()), title: String(item.title).trim(), grade: Number(item.grade), type: String(item.type), description: String(item.description || ''), url: String(item.url || ''), drive_id: String(item.driveId || ''), file_name: String(item.fileName || ''), created_at: new Date().toISOString() };
      const existing = await getRows('materials', `select=id&id=eq.${enc(row.id)}&limit=1`);
      if (existing?.length) await sb(`/rest/v1/materials?id=eq.${enc(row.id)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(row) });
      else await sb('/rest/v1/materials', { method: 'POST', headers: { Prefer: 'return=minimal' }, body: JSON.stringify(row) });
      return await initialData();
    }
    case 'deleteMaterial': {
      requireAdmin(args[0]); const id = String(args[1]);
      const old = await getRows('materials', `select=id,drive_id&id=eq.${enc(id)}&limit=1`);
      if (old?.[0]?.drive_id) { try { await sb(`/storage/v1/object/${enc(BUCKET)}/${old[0].drive_id}`, { method: 'DELETE' }); } catch {} }
      await sb(`/rest/v1/materials?id=eq.${enc(id)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
      return await initialData();
    }
    case 'uploadMaterial': {
      requireAdmin(args[0]); const file = args[1] || {};
      if (!file.data) throw new Error('File kosong atau tidak terbaca.');
      const buffer = Buffer.from(String(file.data), 'base64');
      if (!buffer.length) throw new Error('File kosong atau tidak terbaca.');
      if (buffer.length > 4 * 1024 * 1024) throw new Error('Ukuran file maksimal 4 MB per unggahan.');
      const original = String(file.name || 'materi.bin').split(/[\\/]/).pop().replace(/[^\p{L}\p{N}._ -]/gu, '_').slice(0, 140) || 'materi.bin';
      const objectPath = `${Date.now()}-${crypto.randomUUID()}-${original}`;
      let mime = String(file.mimeType || 'application/octet-stream');
      if (/\.html?$/i.test(original)) mime = 'text/html';
      const result = await fetch(`${SUPABASE_URL}/storage/v1/object/${enc(BUCKET)}/${objectPath}`, { method: 'POST', headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type': mime, 'x-upsert': 'false', 'cache-control': '3600' }, body: buffer });
      const raw = await result.text(); let parsed; try { parsed = raw ? JSON.parse(raw) : {}; } catch { parsed = { message: raw }; }
      if (!result.ok) throw new Error(parsed.message || parsed.error || `Gagal mengunggah file (${result.status}). Pastikan bucket '${BUCKET}' sudah dibuat.`);
      const url = `${SUPABASE_URL}/storage/v1/object/public/${enc(BUCKET)}/${objectPath.split('/').map(enc).join('/')}`;
      return { driveId: objectPath, fileName: original, url, viewUrl: url, shareEnabled: true, shareWarning: '' };
    }
    case 'saveSettings': {
      requireAdmin(args[0]); const settings = args[1] || {};
      const rows = Object.entries(settings).map(([key, value]) => ({ key, value: String(value ?? '') }));
      for (const row of rows) await sb('/rest/v1/settings?on_conflict=key', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify(row) });
      return await initialData();
    }
    case 'saveGradeCode': {
      requireAdmin(args[0]); const grade = Number(args[1]), enabled = Boolean(args[2]), code = String(args[3] || '');
      if (![7, 8, 9].includes(grade)) throw new Error('Kelas harus 7, 8, atau 9.');
      if (enabled && code.trim().length < 4) throw new Error('Kode akses minimal 4 karakter.');
      await sb('/rest/v1/grade_codes?on_conflict=grade', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ grade, enabled, code: enabled ? code : '' }) });
      return await initialData();
    }
    case 'verifyGrade': {
      const [grade, code] = args; const rows = await getRows('grade_codes', `select=grade,enabled,code&grade=eq.${enc(Number(grade))}&limit=1`); const c = rows?.[0];
      if (!c || !c.enabled) return { ok: true };
      return { ok: String(c.code) === String(code), message: 'Kode akses tidak sesuai.' };
    }
    case 'changePassword': {
      const user = requireAdmin(args[0]); const [oldPass, newPass] = args.slice(1);
      if (String(newPass || '').length < 8) throw new Error('Password baru minimal 8 karakter.');
      const rows = await getRows('users', `select=username,password_hash&username=eq.${enc(user.username)}&limit=1`);
      if (!rows?.[0] || rows[0].password_hash !== sha256(oldPass)) throw new Error('Password lama salah.');
      await sb(`/rest/v1/users?username=eq.${enc(user.username)}`, { method: 'PATCH', headers: { Prefer: 'return=minimal' }, body: JSON.stringify({ password_hash: sha256(newPass) }) });
      return { ok: true };
    }
    case 'testStorage': return { ok: true, backend: 'Supabase Storage', bucket: BUCKET };
    default: throw new Error(`Aksi tidak dikenal: ${action}`);
  }
}
export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { ...headers, 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'POST,OPTIONS' }, body: '' };
  if (event.httpMethod !== 'POST') return reply(405, { error: 'Gunakan metode POST.' });
  try {
    const body = JSON.parse(event.body || '{}');
    const data = await handle(String(body.action || ''), Array.isArray(body.args) ? body.args : []);
    return reply(200, { ok: true, data });
  } catch (error) {
    return reply(400, { ok: false, error: error?.message || 'Terjadi kesalahan server.' });
  }
}
