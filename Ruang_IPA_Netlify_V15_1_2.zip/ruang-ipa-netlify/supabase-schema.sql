-- Database Ruang IPA untuk Netlify + Supabase
-- Jalankan seluruh isi file ini di Supabase > SQL Editor > New query.
create extension if not exists pgcrypto;

create table if not exists public.materials (
  id text primary key,
  title text not null,
  grade integer not null check (grade in (7,8,9)),
  type text not null default 'URL',
  description text not null default '',
  url text not null default '',
  drive_id text not null default '',
  file_name text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.settings (
  key text primary key,
  value text not null default ''
);
create table if not exists public.users (
  username text primary key,
  password_hash text not null,
  role text not null default 'admin',
  name text not null default 'Administrator'
);
create table if not exists public.grade_codes (
  grade integer primary key check (grade in (7,8,9)),
  enabled boolean not null default false,
  code text not null default ''
);

insert into public.settings(key,value) values
 ('siteTitle','Ruang IPA'),
 ('runningText','Selamat datang di Ruang IPA • Jelajahi dunia sains • Belajar IPA menjadi menyenangkan •'),
 ('welcomeText','Perpustakaan Digital Belajar IPA untuk Kelas 7, 8, dan 9'),
 ('theme','science')
on conflict (key) do nothing;

-- Login awal: username admin, password RuangIPA#2026
-- Ganti password setelah berhasil login.
insert into public.users(username,password_hash,role,name) values
 ('admin','f435c68efaa2024781c3df948c65617d5bd39348f1eedbe00a72c665a8e6d811','admin','Administrator')
on conflict (username) do nothing;
insert into public.grade_codes(grade,enabled,code) values (7,false,''),(8,false,''),(9,false,'') on conflict (grade) do nothing;

-- Kebijakan RLS: fungsi server Netlify memakai service-role key (rahasia) dan melewati RLS.
-- Jangan pernah memasukkan service-role key ke index.html atau variabel publik.
alter table public.materials enable row level security;
alter table public.settings enable row level security;
alter table public.users enable row level security;
alter table public.grade_codes enable row level security;

-- Bucket publik agar siswa dapat membuka file materi melalui URL, termasuk HTML.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('ruang-ipa','ruang-ipa',true,4194304,array[
 'text/html','text/plain','application/pdf','application/msword',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'image/jpeg','image/png','image/gif','image/webp','video/mp4','audio/mpeg','application/octet-stream'
]) on conflict (id) do update set public=true,file_size_limit=4194304;
