# Ruang IPA — Netlify Edition (V15.1.2)

Paket ini memindahkan tampilan dashboard Ruang IPA dari Apps Script ke website Netlify. Backend disediakan oleh Netlify Functions; database dan penyimpanan file memakai Supabase. Tampilan dashboard mempertahankan tema sains biru, animasi atom, running text, pilihan kelas 7–9, kartu materi, login admin, pengelolaan materi, pengaturan dashboard, kode akses kelas, dan ganti password.

## File paket
- `index.html` — dashboard dan antarmuka admin.
- `netlify/functions/api.mjs` — API server, login admin, CRUD materi, pengaturan, unggah file.
- `netlify.toml` — konfigurasi Netlify.
- `supabase-schema.sql` — tabel database dan bucket penyimpanan.

## A. Siapkan Supabase
1. Buat proyek baru di https://supabase.com/ dan simpan password database di tempat aman.
2. Buka **SQL Editor → New query**, salin seluruh isi `supabase-schema.sql`, lalu tekan **Run**.
3. Buka **Project Settings → API** (atau API Keys). Catat **Project URL** dan **service_role / secret key**. Jangan pernah menaruh service-role key pada file HTML atau membagikannya ke siswa.
4. SQL membuat bucket publik `ruang-ipa` agar file pembelajaran dapat dibuka siswa. Kebijakan organisasi mungkin mengatur ulang akses publik; pastikan pengaturan bucket tetap public bila materi memang harus dapat diakses siswa tanpa login.

## B. Unggah ke Netlify
1. Ekstrak ZIP ke folder di komputer.
2. Masuk ke https://app.netlify.com/ lalu pilih **Add new site → Deploy manually**. Unggah folder hasil ekstrak (atau hubungkan repository Git).
3. Setelah situs dibuat, buka **Site configuration → Environment variables** dan tambahkan:
   - `SUPABASE_URL` = Project URL dari Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` = service-role/secret key dari Supabase
   - `TOKEN_SECRET` = string rahasia acak yang panjang (minimal 32 karakter; buat sendiri, jangan gunakan password login admin)
   - `SUPABASE_STORAGE_BUCKET` = `ruang-ipa`
4. Setelah menyimpan environment variables, lakukan **Deploys → Trigger deploy → Clear cache and deploy site**.
5. Buka URL Netlify yang diberikan.

> Untuk Netlify, jangan hanya mengunggah `index.html`. Folder `netlify/functions` dan `netlify.toml` harus ikut terunggah agar login, database, dan upload bekerja.

## C. Login admin
- Username awal: `admin`
- Password awal: `RuangIPA#2026`
- Setelah login, pilih **Ganti Password** dan ubah password awal.

## D. Mengunggah materi
1. Login admin → **Tambah Materi**.
2. Isi judul, kelas, tipe, deskripsi, lalu pilih file. Maksimal 4 MB per file karena batas payload Netlify Functions pada paket ini.
3. Tekan **Simpan Materi**. Materi tersimpan di Supabase Database dan file berada di Supabase Storage.
4. Siswa membuka dashboard, memilih kelas, lalu klik **Buka materi**.
5. File HTML disimpan dengan tipe konten `text/html` dan URL publik sehingga bisa dirender di tab baru. Hanya unggah HTML tepercaya karena kode HTML dapat menjalankan JavaScript di browser siswa.

## Catatan penting
- Apps Script dan Google Sheets/Drive tidak lagi menjadi backend aplikasi Netlify ini; data baru masuk ke Supabase. Data lama di spreadsheet/Drive tidak otomatis dipindahkan. Jika ingin membawa materi lama, salin metadata ke tabel `materials` dan unggah ulang file ke bucket.
- Versi ini memindahkan fitur yang ada pada paket Apps Script: dashboard, kelas 7–9, materi, upload, edit/hapus, pengaturan dashboard, kode akses kelas, dan perubahan password admin. Fitur yang tidak ada di paket Apps Script sumber tidak ditambahkan secara otomatis.
- File PDF/dokumen/gambar dibuka melalui tautan publik. File HTML terbuka sebagai halaman web pada tab baru.
- Bila login/upload gagal, periksa **Netlify → Functions → api → Logs** dan pastikan ketiga variabel `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, dan `TOKEN_SECRET` sudah benar.
